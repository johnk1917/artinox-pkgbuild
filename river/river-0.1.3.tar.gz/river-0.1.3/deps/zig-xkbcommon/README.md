# zig-xkbcommon

[zig](https://ziglang.org/) 0.9.0 bindings for
[xkbcommon](https://xkbcommon.org) that are a little
nicer to use than the output of `zig translate-c`.
