# zig-pixman

[zig](https://ziglang.org/) bindings for
[pixman](https://gitlab.freedesktop.org/pixman/pixman) that are a little
nicer to use than the output of `zig translate-c`.
