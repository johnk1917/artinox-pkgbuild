require "libsixel/version"
require "libsixel/libsixel"

module Libsixel
  # Your code goes here...
end
